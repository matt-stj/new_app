(function() {
  ActiveAdmin.PerPage = (function() {
    function PerPage(_at_options, _at_element) {
      this.options = _at_options;
      this.element = _at_element;
      this.$element = $(this.element);
      this._init();
      this._bind();
    }

    PerPage.prototype._init = function() {
      return this.$params = this._queryParams();
    };

    PerPage.prototype._bind = function() {
      return this.$element.change((function(_this) {
        return function() {
          _this.$params['per_page'] = _this.$element.val();
          delete _this.$params['page'];
          return location.search = $.param(_this.$params);
        };
      })(this));
    };

    PerPage.prototype._queryParams = function() {
      var m, params, query, re;
      query = window.location.search.substring(1);
      params = {};
      re = /([^&=]+)=([^&]*)/g;
      while (m = re.exec(query)) {
        params[decodeURIComponent(m[1])] = decodeURIComponent(m[2]);
      }
      return params;
    };

    return PerPage;

  })();

  $.widget.bridge('perPage', ActiveAdmin.PerPage);

  $(function() {
    return $('.pagination_per_page select').perPage();
  });

}).call(this);
